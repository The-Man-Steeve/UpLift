package application;

import java.util.List;

public class Workout {
	
	
	public String Title;
	public String Date_Created;
	public List<Exercise> Exercises;
	public String Note;
	
	
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public String getDate_Created() {
		return Date_Created;
	}
	public void setDate_Created(String date_Created) {
		Date_Created = date_Created;
	}
	public List<Exercise> getExercises() {
		return Exercises;
	}
	public void setExercises(List<Exercise> workout) {
		this.Exercises = workout;
	}
	public void setNote(String note) {
		Note = note;
	}
	public String getNote() {
		return Note;
	}
	public String printWorkout() {
		//System.out.println(this.getTitle() + ":");
		String output = "";
		for(Exercise e: Exercises) {
			//Hierarchy:
			//Name: Sets x Reps; Weight, Distance, Time, *RestTime* rest;
			//		Note: *note*
			output += (e.getName() + " ");
			output += (e.getSets() > 0 ? e.getSets() + "x" : "");
			output += (e.getReps() > 0 ? e.getReps(): "");
			output += (e.getTime() != null ? e.getTime(): "");
			output += (e.getWeight() > 0 ? ", " + e.getWeight() + " " + e.getWeightMeasurement(): "");
			output += (e.getDistance() != 0 ? ", " + e.getDistance() + " " + e.getDistanceMeasurement(): "");
			output += (e.getNote() != null ? "\n\tNOTE: " + e.getNote(): "");
			output += "\n";
		}
		return output;
	}
	public String printMetadata() {
		String output = "";
		output += "Workout Name: " + this.Title + "\n";
		output += "Date Created: " + Date_Created + "\n";
		output += "Additional Notes: " + this.Note;
		return output;
	}
}
