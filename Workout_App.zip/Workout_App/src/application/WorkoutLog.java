package application;

import java.util.Collections;
import java.util.List;

public class WorkoutLog {
	
	private List<LogEntry> log;

	public List<LogEntry> getLog() {
		return log;
	}

	public void setLog(List<LogEntry> log) {
		this.log = log;
	}
	
	public void sortLog() {
		Collections.sort(log, );
	}
	
}
