package application;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LogEntry {
	@JsonProperty("Date")
	private String Date;
	@JsonProperty("Time")
	private String Time;
	@JsonProperty("Exercises")
	private List<Exercise> Exercises;
	@JsonProperty("Note")
	private String Note;
	//Add an image in the future
	public LogEntry() {
		//do nothing
	}
	
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getTime() {
		return Time;
	}
	public void setTime(String time) {
		Time = time;
	}
	public List<Exercise> getExercises() {
		return Exercises;
	}
	public void setExercises(List<Exercise> exercises) {
		Exercises = exercises;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	public String printExercises() {
		//System.out.println(this.getTitle() + ":");
		String output = "";
		for(Exercise e: Exercises) {
			//Hierarchy:
			//Name: Sets x Reps; Weight, Distance, Time, *RestTime* rest;
			//		Note: *note*
			output += (e.getName() + " ");
			output += (e.getSets() > 0 ? e.getSets() + "x" : "");
			output += (e.getReps() > 0 ? e.getReps(): "");
			output += (e.getTime() != null ? e.getTime(): "");
			output += (e.getWeight() > 0 ? ", " + e.getWeight() + " " + e.getWeightMeasurement(): "");
			output += (e.getDistance() != 0 ? ", " + e.getDistance() + " " + e.getDistanceMeasurement(): "");
			output += (e.getNote() != null ? "\n\tNOTE: " + e.getNote(): "");
			output += "\n";
		}
		return output;
	}
	
	
}
