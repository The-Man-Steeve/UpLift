package application;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.MonthDay;
import java.time.YearMonth;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class CalendarController {
	
	private Stage stage;
	private Scene scene;
	@FXML
	private Label MonthLabel;
	@FXML
	private GridPane Calendar;
	@FXML
	private Label DateLabel;
	@FXML
	private Label SelectedDay;
	
	private YearMonth currentYearMonth = YearMonth.now();
	private MonthDay today = MonthDay.now();
	
	@FXML
	public void initialize() {
		MonthLabel.setText(currentYearMonth.getMonth().toString() + "  " + currentYearMonth.getYear());
		populateCalendar();
		
	}
	
	public void GoToHome(ActionEvent event) throws IOException{
		Parent root = FXMLLoader.load(getClass().getResource("MainScene.fxml"));
		stage = (Stage)((Node)(event.getSource())).getScene().getWindow();
		scene = new Scene(root);
		stage.setScene(scene);
		stage.show();
	}
	@FXML
	public void prevMonth(ActionEvent event) {
		currentYearMonth = currentYearMonth.minusMonths(1);
		MonthLabel.setText(currentYearMonth.getMonth().toString() + "  " + currentYearMonth.getYear());
		populateCalendar();
	}
	@FXML
	public void nextMonth(ActionEvent e) {
		currentYearMonth = currentYearMonth.plusMonths(1);
		MonthLabel.setText(currentYearMonth.getMonth().toString() + "  " + currentYearMonth.getYear());
		populateCalendar();
	}
	@FXML
	public void populateCalendar() {
		//workspace
		String filename = currentYearMonth.getMonth().toString() + currentYearMonth.getYear() + "Log" + ".json";
		System.out.println(filename);
		filename = "src/Logs/" + filename;
		System.out.println(System.getProperty("user.dir"));
		ObjectMapper mapper = new ObjectMapper();
		LogEntry log = new LogEntry();
		try {
			log = mapper.readValue(new File(filename), LogEntry.class);
		} catch (StreamReadException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DatabindException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.print(log.printExercises());
		//
		Calendar.getChildren().removeIf(node -> GridPane.getRowIndex(node) != null && GridPane.getRowIndex(node) > 0);
		LocalDate test = currentYearMonth.atDay(1);
		int dayOfWeek = test.getDayOfWeek().getValue() % 7;
		int week = 1;
		//System.out.print(Calendar);
		for(int i = 1; i <= currentYearMonth.lengthOfMonth(); i++) {
			final int dayNumber = i;
			StackPane cell = new StackPane();
			Label dayLabel = new Label();
			dayLabel.setText("" + i);
			dayLabel.setStyle("-fx-font-size: 30;");
			dayLabel.setPrefSize(40.0, 40.0);
			dayLabel.setAlignment(Pos.CENTER);
			dayLabel.setCursor(Cursor.HAND);
			dayLabel.setOnMouseClicked(event -> clickOnDay(dayNumber, dayLabel));
			
			cell.getChildren().add(dayLabel);
			if (dayNumber == today.getDayOfMonth() && currentYearMonth.getMonthValue() == today.getMonthValue()){
				clickOnDay(dayNumber, dayLabel);
			}
			
			//AnchorPane.setRightAnchor(dayLabel, 10.0);
			//cell.setStyle("-fx-border-color: black;");
			Calendar.add(cell, dayOfWeek, week);
			//dayLabel.setAlignment(null);
			//System.out.println("Day " + i + " at week: " + week + ", day: " + dayOfWeek);
			dayOfWeek += 1;
			if (dayOfWeek == 7) {
				dayOfWeek = 0;
				week += 1;
			}
			
		}
	}
	private void clickOnDay(int day, Label clickedDay) {
		//System.out.println("clicked on " + currentYearMonth.getMonth().toString() + " " + day);
		DateLabel.setText(currentYearMonth.getMonth().toString() + " " + day + ", " + currentYearMonth.getYear());
		if(SelectedDay != null) {
			SelectedDay.getStyleClass().remove("selected-date");
		}
		clickedDay.getStyleClass().add("selected-date");
		SelectedDay = clickedDay;
		
	}
}
